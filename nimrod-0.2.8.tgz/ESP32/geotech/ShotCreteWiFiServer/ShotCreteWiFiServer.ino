/*
Shot Crete WiFi server
*/

// Import required libraries
#include "WiFi.h"


// Set your access point network credentials
const char* ssid = "ESP32-Access-Point";
const char* password = "123456789";
bool connected = false;
long lLastMsec = 0;
long lPingPeriod = 1000;

WiFiServer server(5123);
WiFiClient client;


void setup(){
  // Serial port for debugging purposes
  Serial.begin(115200);
  Serial.println();
  
  // Setting the ESP as an access point
  Serial.print("Setting AP (Access Point)…");
  // Remove the password parameter, if you want the AP (Access Point) to be open
  WiFi.softAP(ssid, password);

  IPAddress IP = WiFi.softAPIP();
  Serial.print("AP IP address: ");
  Serial.println(IP);

  // Start server
  server.begin();
}
 

void loop(){
  if (!connected) {
    delay(1000);
    client = server.available();
    if (client) {
      Serial.println("Got a client !");
      if (client.connected()) {
        Serial.println("and it's connected!");
        connected = true;
      } else {
        Serial.println("but it's not connected!");
        client.stop();  
      }
    } else {
      Serial.println("no client connected");
    }
  } else {
    if (client.connected()) {
      bool bGotMsg = false;
      while (client.available()) {
        // read msg from client
        bGotMsg = true;
        Serial.write(client.read());
      }

      if ( bGotMsg ) {
        // send to client
        lLastMsec = millis();
        client.write("sack\n");
      } else if ( lLastMsec + lPingPeriod < millis() ) {
        lLastMsec = millis();
        client.write("sping\n");
      }
    } else {
      Serial.println("Client is gone");
      client.stop();  
      connected = false;
    }
  }  
}