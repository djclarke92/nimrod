/*
ShotCrete WiFi Client
*/

#include <WiFi.h>

#define DEBOUNCE_TIME   30
#define JS_SIZE         4

bool bJS1[JS_SIZE] = { HIGH, HIGH, HIGH, HIGH };
bool bJS2[JS_SIZE] = { HIGH, HIGH, HIGH, HIGH };
bool bJS3[JS_SIZE] = { HIGH, HIGH, HIGH, HIGH };
bool bJS4[JS_SIZE] = { HIGH, HIGH, HIGH, HIGH };
bool bJS1_last[JS_SIZE] = { HIGH, HIGH, HIGH, HIGH };
bool bJS2_last[JS_SIZE] = { HIGH, HIGH, HIGH, HIGH };
bool bJS3_last[JS_SIZE] = { HIGH, HIGH, HIGH, HIGH };
bool bJS4_last[JS_SIZE] = { HIGH, HIGH, HIGH, HIGH };
int iJS1_pin[JS_SIZE] = {(gpio_num_t)16, (gpio_num_t)17, (gpio_num_t)18, (gpio_num_t)19 };
int iJS2_pin[JS_SIZE] = {(gpio_num_t)4, (gpio_num_t)21, (gpio_num_t)22, (gpio_num_t)23 };
int iJS3_pin[JS_SIZE] = {(gpio_num_t)25, (gpio_num_t)26, (gpio_num_t)27, (gpio_num_t)32 };
int iJS4_pin[JS_SIZE] = {(gpio_num_t)33, (gpio_num_t)34, (gpio_num_t)35, (gpio_num_t)36 };
int iCount = 0;
int iJoystick1 = 0;
int iJoystick2 = 0;
int iJoystick3 = 0;
int iJoystick4 = 0;
int iLastJoystick1 = 0;
int iLastJoystick2 = 0;
int iLastJoystick3 = 0;
int iLastJoystick4 = 0;
long lLastTime = 0;
long lLastMsec = 0;
long lPeriod = 1000;
long lJS1_msec[JS_SIZE] = { 0, 0, 0, 0 };
long lJS2_msec[JS_SIZE] = { 0, 0, 0, 0 };
long lJS3_msec[JS_SIZE] = { 0, 0, 0, 0 };
long lJS4_msec[JS_SIZE] = { 0, 0, 0, 0 };
const uint16_t portNumber = 5123;
const char* ssid = "ESP32-Access-Point";
const char* password = "123456789";
String sMsg;
IPAddress serverIP;

WiFiClient client;


void readInputs();

void setup() {
  Serial.begin(115200);

  for ( int i = 0; i < JS_SIZE; i++ ) {
    pinMode(iJS1_pin[i], INPUT_PULLUP);
    pinMode(iJS2_pin[i], INPUT_PULLUP);
    pinMode(iJS3_pin[i], INPUT_PULLUP);
    pinMode(iJS4_pin[i], INPUT_PULLUP);
  }

  WiFi.mode(WIFI_STA);

  WiFi.begin(ssid, password);
  Serial.println("Connecting");
  while(WiFi.status() != WL_CONNECTED) { 
    delay(500);
    Serial.print(".");
  }
  Serial.println("");
  Serial.print("Connected to WiFi network with IP Address: ");
  Serial.println(WiFi.localIP());

  serverIP = WiFi.gatewayIP();
}

void loop() {
  iCount += 1;
  if ( lLastTime + 10000 < millis()) {
    lLastTime = millis();
    sMsg = "Count ";
    sMsg += iCount/10;
    sMsg += "\n";
    Serial.write(sMsg.c_str());
    iCount = 0;
  }

  readInputs();
  if (!client.connected()) {
    if (client.connect(serverIP, portNumber)) {
      Serial.print("Connected to Gateway IP = "); Serial.println(serverIP);
    } else {
      Serial.print("Could NOT connect to Gateway IP = "); Serial.println(serverIP);
      delay(500);
    }
  } else {
   
    while (client.available()) Serial.write(client.read());
    
    // send switch status
    if ( iJoystick1 != iLastJoystick1 ) {
      iLastJoystick1 = iJoystick1;
      sMsg = "SW1_";
      sMsg += iJoystick1;
      sMsg += "\n";
      client.write( sMsg.c_str() );
      Serial.write(sMsg.c_str());
    }

    if ( iJoystick2 != iLastJoystick2 ) {
      iLastJoystick2 = iJoystick2;
      sMsg = "SW2_";
      sMsg += iJoystick2;
      sMsg += "\n";
      client.write( sMsg.c_str() );
      Serial.write(sMsg.c_str());
    }

    if ( iJoystick3 != iLastJoystick3 ) {
      iLastJoystick3 = iJoystick3;
      sMsg = "SW3_";
      sMsg += iJoystick3;
      sMsg += "\n";
      client.write( sMsg.c_str() );
      Serial.write(sMsg.c_str());
    }

    if ( iJoystick4 != iLastJoystick4 ) {
      iLastJoystick4 = iJoystick4;
      sMsg = "SW4_";
      sMsg += iJoystick4;
      sMsg += "\n";
      client.write( sMsg.c_str() );
      Serial.write(sMsg.c_str());
    }

    if ( lLastMsec + lPeriod < millis() ) {
      lLastMsec = millis();
      client.write("cping\n");
    }
  }
}

void readInputs() {
  int i;

  for ( i = 0; i < JS_SIZE; i++ ) {  
    bJS1[i] = digitalRead(iJS1_pin[i]);
    if ( bJS1[i] != bJS1_last[i] && lJS1_msec[i] == 0 ) {
      // state has changed
      lJS1_msec[i] = millis();
    } else if ( bJS1[i] == bJS1_last[i] && lJS1_msec[i] != 0 ) {
      // clear the debounce timer
      lJS1_msec[i] = 0;
    } else if ( lJS1_msec[i] != 0 && lJS1_msec[i] + DEBOUNCE_TIME < millis() ) {
      // debounce time has expired, send the new switch state
      bJS1_last[i] = bJS1[i];
      if ( bJS1[i] == HIGH ) {
        // not pressed - clear the bit
        iJoystick1 &= ~((0x01 << i));
      } else {
        // pressed, set the bit
        iJoystick1 |= (0x01 << i);
      }
    }
  }

  for ( i = 0; i < JS_SIZE; i++ ) {  
    bJS2[i] = digitalRead(iJS2_pin[i]);
    if ( bJS2[i] != bJS2_last[i] && lJS2_msec[i] == 0 ) {
      // state has changed
      lJS2_msec[i] = millis();
    } else if ( bJS2[i] == bJS2_last[i] && lJS2_msec[i] != 0 ) {
      // clear the debounce timer
      lJS2_msec[i] = 0;
    } else if ( lJS2_msec[i] != 0 && lJS2_msec[i] + DEBOUNCE_TIME < millis() ) {
      // debounce time has expired, send the new switch state
      bJS2_last[i] = bJS2[i];
      if ( bJS2[i] == HIGH ) {
        // not pressed - clear the bit
        iJoystick2 &= ~((0x01 << i));
      } else {
        // pressed, set the bit
        iJoystick2 |= (0x01 << i);
      }
    }
  }

  for ( i = 0; i < JS_SIZE; i++ ) {  
    bJS3[i] = digitalRead(iJS3_pin[i]);
    if ( bJS3[i] != bJS3_last[i] && lJS3_msec[i] == 0 ) {
      // state has changed
      lJS3_msec[i] = millis();
    } else if ( bJS3[i] == bJS3_last[i] && lJS3_msec[i] != 0 ) {
      // clear the debounce timer
      lJS3_msec[i] = 0;
    } else if ( lJS3_msec[i] != 0 && lJS3_msec[i] + DEBOUNCE_TIME < millis() ) {
      // debounce time has expired, send the new switch state
      bJS3_last[i] = bJS3[i];
      if ( bJS3[i] == HIGH ) {
        // not pressed - clear the bit
        iJoystick3 &= ~((0x01 << i));
      } else {
        // pressed, set the bit
        iJoystick3 |= (0x01 << i);
      }
    }
  }

  for ( i = 0; i < JS_SIZE; i++ ) {  
    bJS4[i] = digitalRead(iJS4_pin[i]);
    if ( bJS4[i] != bJS4_last[i] && lJS4_msec[i] == 0 ) {
      // state has changed
      lJS4_msec[i] = millis();
    } else if ( bJS4[i] == bJS4_last[i] && lJS4_msec[i] != 0 ) {
      // clear the debounce timer
      lJS4_msec[i] = 0;
    } else if ( lJS4_msec[i] != 0 && lJS4_msec[i] + DEBOUNCE_TIME < millis() ) {
      // debounce time has expired, send the new switch state
      bJS4_last[i] = bJS4[i];
      if ( bJS4[i] == HIGH ) {
        // not pressed - clear the bit
        iJoystick4 &= ~((0x01 << i));
      } else {
        // pressed, set the bit
        iJoystick4 |= (0x01 << i);
      }
    }
  }

}


