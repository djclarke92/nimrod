/*
ShotCrete WiFi Client 2
*/

#include <WiFi.h>

#define DEBOUNCE_TIME   30
#define BTN_SIZE         8
#define OUT_SIZE         2
#define RSSI_LED        (gpio_num_t)5

bool bBtn[BTN_SIZE] = { HIGH, HIGH, HIGH, HIGH, HIGH, HIGH, HIGH, HIGH };
bool bBtn_last[BTN_SIZE] = { HIGH, HIGH, HIGH, HIGH, HIGH, HIGH, HIGH, HIGH };
int iBtn_pin[BTN_SIZE] = {(gpio_num_t)16, (gpio_num_t)17, (gpio_num_t)18, (gpio_num_t)19,
                          (gpio_num_t)4, (gpio_num_t)21, (gpio_num_t)22, (gpio_num_t)23 };
// gpio 12 cannot be used a an output
int iOut_pin[OUT_SIZE] = { (gpio_num_t)13, (gpio_num_t)14 };  // active low
//int iJS3_pin[JS_SIZE] = {(gpio_num_t)12, (gpio_num_t)13, (gpio_num_t)14, (gpio_num_t)15 };
//int iJS4_pin[JS_SIZE] = {(gpio_num_t)26, (gpio_num_t)27, (gpio_num_t)32, (gpio_num_t)33 };
int iCount = 0;
int iButton[BTN_SIZE] = { 0, 0, 0, 0, 0, 0, 0, 0 };
int iLastButton[BTN_SIZE] = { 0, 0, 0, 0, 0, 0, 0, 0 };
int iRssiLevel = 0;
int iRssiCount = 0;
long lLastRssiTime = 0;
long lLastTime = 0;
long lLastMsec = 0;
long lPeriod = 1000;
long lBtn_msec[BTN_SIZE] = { 0, 0, 0, 0, 0, 0, 0, 0 };
const uint16_t portNumber = 5123;
const char* ssid = "ESP32-Access-Point2";
const char* password = "987654321";
String sMsg;
IPAddress serverIP;

WiFiClient client;


void readInputs();
void setRssiLed();

void setup() {
  int i;

  Serial.begin(115200);

  pinMode( RSSI_LED, OUTPUT);
  digitalWrite( RSSI_LED, HIGH );
  for ( i = 0; i < BTN_SIZE; i++ ) {
    pinMode(iBtn_pin[i], INPUT_PULLUP);
  }
  for ( i = 0; i < OUT_SIZE; i++ ) {
    pinMode( iOut_pin[i], OUTPUT );
    digitalWrite( iOut_pin[i], HIGH);
  }

  WiFi.mode(WIFI_STA);

  WiFi.begin(ssid, password);
  Serial.println("Connecting");
  while(WiFi.status() != WL_CONNECTED) { 
    // wait for a connection
    if ( lLastRssiTime + 100 < millis() ) {
      lLastRssiTime = millis();
      setRssiLed();
    }

    if ( lLastTime + 500 < millis()) {
      lLastTime = millis();
      Serial.print(".");
    }
  }
  Serial.println("");
  Serial.print("Connected to WiFi network with IP Address: ");
  Serial.println(WiFi.localIP());

  serverIP = WiFi.gatewayIP();
}

void loop() {
  iCount += 1;
  if ( lLastTime + 10000 < millis()) {
    lLastTime = millis();
    sMsg = "Count ";
    sMsg += iCount/10;
    sMsg += "\n";
    Serial.write(sMsg.c_str());
    iCount = 0;
  }
  if ( lLastRssiTime + 100 < millis() ) {
    lLastRssiTime = millis();
    setRssiLed();
  }

  readInputs();
  if (!client.connected()) {
    if (client.connect(serverIP, portNumber)) {
      Serial.print("Connected to Gateway IP = "); Serial.println(serverIP);
    } else {
      Serial.print("Could NOT connect to Gateway IP = "); Serial.println(serverIP);
      delay(500);
    }
  } else {
   
    sMsg = "";
    while (client.available()) {
      sMsg = client.readStringUntil('\n');
      Serial.println(sMsg);
    }

    // read led state from server
    // 0123456
    // IPx_yy
    if ( sMsg.startsWith("IP") ) {
      int iVal = sMsg.substring(4).toInt();
      int iLed = sMsg.substring(2).toInt();

      changeOutputs( iLed, iVal );
    }

    // send switch status
    for ( int i = 0; i < BTN_SIZE; i++ ) {
      if ( iButton[i] != iLastButton[i] ) {
        iLastButton[i] = iButton[i];
        sMsg = "BN";
        sMsg += i;
        sMsg += "_";
        sMsg += iButton[i];
        sMsg += "\n";
        client.write( sMsg.c_str() );
        Serial.write(sMsg.c_str());
      }
    }

    if ( lLastMsec + lPeriod < millis() ) {
      lLastMsec = millis();
      iRssiLevel = WiFi.RSSI();
      sMsg = "sping ";
      sMsg += WiFi.RSSI();
      sMsg += ".";
      sMsg += "\n";
      client.write(sMsg.c_str());

      sMsg = "RSSI ";
      sMsg += WiFi.RSSI();
      sMsg += "\n";
      Serial.write(sMsg.c_str());
    }

  }
}

// active low leds
void changeOutputs( int iLed, int iVal ) {
  if ( iLed >= 0 && iLed < OUT_SIZE ) {
    if ( iVal == 0 )
      digitalWrite( iOut_pin[iLed], HIGH );
    else
      digitalWrite( iOut_pin[iLed], LOW );      
  } 
}

void readInputs() {
  int i;

  for ( i = 0; i < BTN_SIZE; i++ ) {  
    bBtn[i] = digitalRead(iBtn_pin[i]);
    if ( bBtn[i] != bBtn_last[i] && lBtn_msec[i] == 0 ) {
      // state has changed
      lBtn_msec[i] = millis();
    } else if ( bBtn[i] == bBtn_last[i] && lBtn_msec[i] != 0 ) {
      // clear the debounce timer
      lBtn_msec[i] = 0;
    } else if ( lBtn_msec[i] != 0 && lBtn_msec[i] + DEBOUNCE_TIME < millis() ) {
      // debounce time has expired, send the new switch state
      bBtn_last[i] = bBtn[i];
      if ( bBtn[i] == HIGH ) {
        // not pressed - clear the bit
        iButton[i] = 0;
      } else {
        // pressed, set the bit
        iButton[i] = 1;
      }
    }
  }

}

// rssi led - LOW = on
void setRssiLed() {
  iRssiCount += 1;
  if ( iRssiCount >= 10 ) {
    iRssiCount = 0;
  }
  //Serial.println("setRssiLed");
  if ( client.connected() ) {
    if ( iRssiLevel > -80 ) {
      // good signal - solid led
      if ( iRssiCount == 0 )
        digitalWrite( RSSI_LED, HIGH );
      else
        digitalWrite( RSSI_LED, LOW );
    } else {
      // bad signal - blink the led
      if ( (iRssiCount % 2) == 0 ) {
        digitalWrite( RSSI_LED, LOW );
      } else {
        digitalWrite( RSSI_LED, HIGH );
      }
    }
  } else {
    if ( iRssiCount == 0 )
      digitalWrite( RSSI_LED, LOW );
    else
      digitalWrite( RSSI_LED, HIGH );
  }
}
