/*
Shot Crete WiFi server 2
*/

// Import required libraries
#include "WiFi.h"

#define DEBOUNCE_TIME   30
#define BTN_SIZE         8
#define OUT_SIZE         2
#define RSSI_LED        (gpio_num_t)5

void changeOutputs( int iBtn, int iVal );
void setRssiLed();
void readInputs();

// Set your access point network credentials
const char* ssid = "ESP32-Access-Point2";
const char* password = "987654321";
bool connected = false;
int iClientRssiLevel = 0;
int iRssiCount = 0;
bool bOut[OUT_SIZE] = { HIGH, HIGH };
bool bOut_last[OUT_SIZE] = { HIGH, HIGH };
int iBtn_pin[BTN_SIZE] = {(gpio_num_t)16, (gpio_num_t)17, (gpio_num_t)18, (gpio_num_t)19,
                          (gpio_num_t)4, (gpio_num_t)21, (gpio_num_t)22, (gpio_num_t)23 };
int iOut_pin[OUT_SIZE] = { (gpio_num_t)13, (gpio_num_t)14 };
//int iJS3_pin[JS_SIZE] = {(gpio_num_t)12, (gpio_num_t)13, (gpio_num_t)14, (gpio_num_t)15 };
//int iJS4_pin[JS_SIZE] = {(gpio_num_t)26, (gpio_num_t)27, (gpio_num_t)32, (gpio_num_t)33 };
int iInput[OUT_SIZE] = { 0, 0 };
int iLastInput[OUT_SIZE] = { 0, 0 };
long lOut_msec[OUT_SIZE] = { 0, 0 };
long lLastConnectTime = 0;
long lLastMsec = 0;
long lLastClientMsec = 0;
long lPingPeriod = 1000;
long lLastRssiTime = 0;
time_t tLastTime = 0;

WiFiServer server(5123);
WiFiClient client;


void setup(){
  int i;

  // Serial port for debugging purposes
  Serial.begin(115200);
  Serial.println();

  pinMode( RSSI_LED, OUTPUT );  
  for ( i = 0; i < BTN_SIZE; i++ ) {
    pinMode(iBtn_pin[i], OUTPUT);
    digitalWrite( iBtn_pin[i], LOW);
  }
  for ( i = 0; i < OUT_SIZE; i++ ) {
    pinMode( iOut_pin[i], INPUT_PULLUP );
  }

  // Setting the ESP as an access point
  Serial.print("Setting AP (Access Point)…");
  // Remove the password parameter, if you want the AP (Access Point) to be open
  WiFi.softAP(ssid, password);

  IPAddress IP = WiFi.softAPIP();
  Serial.print("AP IP address: ");
  Serial.println(IP);

  // Start server
  server.begin();
}
 

void loop(){
  if ( lLastRssiTime + 100 < millis() ) {
    lLastRssiTime = millis();
    setRssiLed();
  }

  readInputs();
  if (!connected) {
    // try once a second
    if ( lLastConnectTime + 1000 < millis() ) {
      lLastConnectTime = millis();
      client = server.available();
      if (client) {
        Serial.println("Got a client !");
        if (client.connected()) {
          Serial.println("and it's connected!");
          connected = true;
        } else {
          Serial.println("but it's not connected!");
          client.stop();  
        }
      } else {
        Serial.println("no client connected");
      }
    }
  } else {
    if (client.connected()) {
      bool bGotMsg = false;
      String sMsg;
      while (client.available()) {
        // read msg from client
        bGotMsg = true;
        lLastClientMsec = millis();
        sMsg = client.readStringUntil('\n');
        Serial.println(sMsg);

        // client sping contains the client rssi level

        // 0123456
        // BNx_yy
        if ( sMsg.startsWith("BN") ) {
          int iVal = sMsg.substring(4).toInt();
          int iBtn = sMsg.substring(2).toInt();

          changeOutputs( iBtn, iVal );
        } else if ( sMsg.startsWith("sping") ) {
          // 01234567890
          // sping -78
          iClientRssiLevel = sMsg.substring(6).toInt(); 
          //Serial.print( "RSSI " );
          //Serial.println( iClientRssi );
        }
      }

      // send switch status
      for ( int i = 0; i < OUT_SIZE; i++ ) {
        if ( iInput[i] != iLastInput[i] ) {
          iLastInput[i] = iInput[i];
          sMsg = "IP";
          sMsg += i;
          sMsg += "_";
          sMsg += iInput[i];
          sMsg += "\n";
          client.write( sMsg.c_str() );
          Serial.write(sMsg.c_str());
        }
      }

      if ( bGotMsg ) {
        // send to client
        lLastMsec = millis();
        client.write("sack\n");
      } else if ( lLastClientMsec + 2*lPingPeriod < millis() ) {
        // client is dead
        Serial.println("client is dead");
        client.stop();
        connected = false;
      } else if ( lLastMsec + lPingPeriod < millis() ) {
        lLastMsec = millis();
        client.write("sping\n");
        Serial.println("sending sping");
      }
    } else {
      Serial.println("Client is gone");
      client.stop();  
      connected = false;
    }
  }  

  tLastTime = time(NULL);
}

// active high relay outputs
void changeOutputs( int iBtn, int iVal ) {
  if ( iBtn >= 0 && iBtn < BTN_SIZE ) {
    if ( iVal == 0 )
      digitalWrite( iBtn_pin[iBtn], LOW );
    else
      digitalWrite( iBtn_pin[iBtn], HIGH );      
  } 
}

// rssi led - LOW = on
void setRssiLed() {
  iRssiCount += 1;
  if ( iRssiCount >= 10 ) {
    iRssiCount = 0;
  }
  //Serial.println("setRssiLed");
  if ( client.connected() ) {
    if ( iClientRssiLevel > -80 ) {
      // good signal - solid led
      if ( iRssiCount == 0 )
        digitalWrite( RSSI_LED, HIGH );
      else
        digitalWrite( RSSI_LED, LOW );
    } else {
      // bad signal - blink the led
      if ( (iRssiCount % 2) == 0 ) {
        digitalWrite( RSSI_LED, LOW );
      } else {
        digitalWrite( RSSI_LED, HIGH );
      }
    }
  } else {
    if ( iRssiCount == 0 )
      digitalWrite( RSSI_LED, LOW );
    else
      digitalWrite( RSSI_LED, HIGH );
  }
}

void readInputs() {
  int i;

  for ( i = 0; i < OUT_SIZE; i++ ) {  
    bOut[i] = digitalRead(iOut_pin[i]);
    if ( bOut[i] != bOut_last[i] && lOut_msec[i] == 0 ) {
      // state has changed
      lOut_msec[i] = millis();
    } else if ( bOut[i] == bOut_last[i] && lOut_msec[i] != 0 ) {
      // clear the debounce timer
      lOut_msec[i] = 0;
    } else if ( lOut_msec[i] != 0 && lOut_msec[i] + DEBOUNCE_TIME < millis() ) {
      // debounce time has expired, send the new switch state
      bOut_last[i] = bOut[i];
      if ( bOut[i] == HIGH ) {
        // not pressed - clear the bit
        iInput[i] = 0;
      } else {
        // pressed, set the bit
        iInput[i] = 1;
      }
    }
  }

}
