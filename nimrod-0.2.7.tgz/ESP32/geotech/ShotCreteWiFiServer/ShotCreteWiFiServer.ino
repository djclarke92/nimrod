/*
Shot Crete WiFi server
*/

// Import required libraries
#include "WiFi.h"

#define JS_SIZE         4
#define RSSI_LED        (gpio_num_t)5

void changeOutputs( int iJs, int iVal );
void setRssiLed();

// Set your access point network credentials
const char* ssid = "ESP32-Access-Point";
const char* password = "123456789";
bool connected = false;
int iClientRssiLevel = 0;
int iJS1_pin[JS_SIZE] = {(gpio_num_t)16, (gpio_num_t)17, (gpio_num_t)18, (gpio_num_t)19 };
int iJS2_pin[JS_SIZE] = {(gpio_num_t)4, (gpio_num_t)21, (gpio_num_t)22, (gpio_num_t)23 };
int iJS3_pin[JS_SIZE] = {(gpio_num_t)12, (gpio_num_t)13, (gpio_num_t)14, (gpio_num_t)15 };
int iJS4_pin[JS_SIZE] = {(gpio_num_t)26, (gpio_num_t)27, (gpio_num_t)32, (gpio_num_t)33 };
int iRssiCount = 0;
long lLastMsec = 0;
long lLastClientMsec = 0;
long lPingPeriod = 1000;
long lLastRssiTime = 0;
long lLastConnectTime = 0;
time_t tLastTime = 0;

WiFiServer server(5123);
WiFiClient client;


void setup(){
  // Serial port for debugging purposes
  Serial.begin(115200);
  Serial.println();

  pinMode( RSSI_LED, OUTPUT );  
  for ( int i = 0; i < JS_SIZE; i++ ) {
    pinMode(iJS1_pin[i], OUTPUT);
    digitalWrite( iJS1_pin[i], LOW);
    pinMode(iJS2_pin[i], OUTPUT);
    digitalWrite( iJS2_pin[i], LOW);
    pinMode(iJS3_pin[i], OUTPUT);
    digitalWrite( iJS3_pin[i], LOW);
    pinMode(iJS4_pin[i], OUTPUT);
    digitalWrite( iJS4_pin[i], LOW);
  }

  // Setting the ESP as an access point
  Serial.print("Setting AP (Access Point)…");
  // Remove the password parameter, if you want the AP (Access Point) to be open
  WiFi.softAP(ssid, password);

  IPAddress IP = WiFi.softAPIP();
  Serial.print("AP IP address: ");
  Serial.println(IP);

  // Start server
  server.begin();
}
 

void loop(){
  if ( lLastRssiTime + 100 < millis() ) {
    lLastRssiTime = millis();
    setRssiLed();
  }

  if (!connected) {
    if ( lLastConnectTime + 1000 < millis() ) {
      lLastConnectTime = millis();

      client = server.available();
      if (client) {
        Serial.println("Got a client !");
        if (client.connected()) {
          Serial.println("and it's connected!");
          connected = true;
        } else {
          Serial.println("but it's not connected!");
          client.stop();  
        }
      } else {
        Serial.println("no client connected");
      }
    }
  } else {
    if (client.connected()) {
      bool bGotMsg = false;
      String sMsg;
      while (client.available()) {
        // read msg from client
        bGotMsg = true;
        lLastClientMsec = millis();
        sMsg = client.readStringUntil('\n');
        Serial.println(sMsg);

        // client sping contains the client rssi level

        // 0123456
        // JSx_yy
        if ( sMsg.startsWith("JS") ) {
          int iVal = sMsg.substring(4).toInt();
          int iJs = sMsg.substring(2).toInt();

          changeOutputs( iJs, iVal );
        } else if ( sMsg.startsWith("sping") ) {
          // 01234567890
          // sping -78
          iClientRssiLevel = sMsg.substring(6).toInt(); 
          //Serial.print( "RSSI " );
          //Serial.println( iClientRssi );
        }
      }

      if ( bGotMsg ) {
        // send to client
        lLastMsec = millis();
        client.write("sack\n");
      } else if ( lLastClientMsec + 2*lPingPeriod < millis() ) {
        // client is dead
        Serial.println("client is dead");
        client.stop();
        connected = false;
      } else if ( lLastMsec + lPingPeriod < millis() ) {
        lLastMsec = millis();
        client.write("sping\n");
        Serial.println("sending sping");
      }
    } else {
      Serial.println("Client is gone");
      client.stop();  
      connected = false;
    }
  }  

  tLastTime = time(NULL);
}

void changeOutputs( int iJs, int iVal ) {
  if ( iJs == 1 ) {
    for ( int i = 0; i < JS_SIZE; i++ ) {
      if ( (iVal & (1<<i)) == 0 )
      digitalWrite( iJS1_pin[i], LOW );
    else
      digitalWrite( iJS1_pin[i], HIGH );      
    }
  } else if ( iJs == 2 ) {
    for ( int i = 0; i < JS_SIZE; i++ ) {
      if ( (iVal & (1<<i)) == 0 )
      digitalWrite( iJS2_pin[i], LOW );
    else
      digitalWrite( iJS2_pin[i], HIGH );      
    }
  } else if ( iJs == 3 ) {
    for ( int i = 0; i < JS_SIZE; i++ ) {
      if ( (iVal & (1<<i)) == 0 )
      digitalWrite( iJS3_pin[i], LOW );
    else
      digitalWrite( iJS3_pin[i], HIGH );      
    }
  } else {
    for ( int i = 0; i < JS_SIZE; i++ ) {
      if ( (iVal & (1<<i)) == 0 )
      digitalWrite( iJS4_pin[i], LOW );
    else
      digitalWrite( iJS4_pin[i], HIGH );      
    }
  }
}

// rssi led - LOW = on
void setRssiLed() {
  iRssiCount += 1;
  if ( iRssiCount >= 10 ) {
    iRssiCount = 0;
  }
  //Serial.println("setRssiLed");
  if ( client.connected() ) {
    if ( iClientRssiLevel > -80 ) {
      // good signal - solid led
      if ( iRssiCount == 0 )
        digitalWrite( RSSI_LED, HIGH );
      else
        digitalWrite( RSSI_LED, LOW );
    } else {
      // bad signal - blink the led
      if ( (iRssiCount % 2) == 0 ) {
        digitalWrite( RSSI_LED, LOW );
      } else {
        digitalWrite( RSSI_LED, HIGH );
      }
    }
  } else {
    if ( iRssiCount == 0 )
      digitalWrite( RSSI_LED, LOW );
    else
      digitalWrite( RSSI_LED, HIGH );
  }
}
