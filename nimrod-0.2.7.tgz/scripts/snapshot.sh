#!/bin/bash


while true; do

	NAME=CHOW1
	DATE=`date +%Y%m%d_%H%M%S`
	FNAME=./${NAME}_${DATE}.jpg

	ffmpeg -loglevel fatal -rtsp_transport tcp -y -i rtsp://camuser:passw0rd.43@192.168.0.13:8554/live2.265 -vframes 1 $FNAME
	echo $FNAME

	sleep 0.5

done

